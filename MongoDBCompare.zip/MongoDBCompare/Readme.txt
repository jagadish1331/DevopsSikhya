How to Start
=============
1) Paste MongoDBCompare folder inside dev folder

2) Folder Location:  C:\dev\MongoDBCompare

3) Right click on Compare Agent and create it's shortcut icon

5) Paste that shortcut icon in desktop

4)Click on CompareAgent